
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Conexao {
   public static void main(String[] args) throws SQLException {
        
       Connection conexao = null;
        try{
            conexao = DriverManager.getConnection
        ("jdbc:mysql://localhost:3306/doceria", "root", "root");
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        String nomeP, nomeF, nomeC, cargoF;
        double precoP;
        int idProduto, idCliente, idFuncionario, quant;
        
        Interface I1 = new Operacoes();
        
        Scanner inN = new Scanner(System.in);
        Scanner inL = new Scanner(System.in);
        int i = 1;
        System.out.println("Escolha uma opção");
        
        while (i != 0){
        
        System.out.println("0 - Fechar Programa");
        System.out.println("-----------------------------");
        System.out.println("1 - Ver Lista de Produtos");
        System.out.println("2 - Cadastrar novo produto");
        System.out.println("3 - Excluir um Produto");
        System.out.println("4 - Fazer uma nova Compra");
        System.out.println("-----------------------------");
        System.out.println("5 - Ver Lista de Funcionario");
        System.out.println("6 - Cadastrar novo Funcionario");
        System.out.println("7 - Demitir um Funcionario");
        System.out.println("-----------------------------");
        System.out.println("8 - Ver Lista de Clientes");
        System.out.println("9 - Cadastrar um novo Cliente");
        System.out.println("10 - Cancelar Cadastro de Cliente");
        System.out.println("-----------------------------");
        i = inN.nextInt();
        
        // numeros invalidos
        if(i < 0 || i > 10){
            System.out.println("Opção invalida, tente novamente");
        }
        
        // ver lista de produtos
        else if(i == 1){
            I1.verListaProd(conexao);
        }
        
        // cadastrar produtos
        else if(i == 2){
            System.out.println("Digite o nome do PRODUTO:");
            nomeP = inL.nextLine();
            I1.setNomeP(nomeP);
            
            
            System.out.println("Digite o valor do PRODUTO:");
            precoP = inN.nextDouble();
            I1.setPrecoP(precoP);
            
            I1.salvarProd(conexao);
        }
        
        // excluir produto
        else if(i == 3){
            I1.verListaProd(conexao);
            System.out.println("Digite o codigo do produto a ser EXCLUIDO: ");
            idProduto = inN.nextInt();
            I1.setIdProduto(idProduto);
            I1.excluirProd(conexao);
            
        }
        
        // realizar nova compra
        else if(i == 4){
            System.out.println("Qual Cliente esta realizando a compra? (digite o id)");
            I1.verListaClient(conexao);
            idCliente = inN.nextInt();
            I1.setIdCliente(idCliente);
            
            System.out.println("Qual Funcionario esta realizando a compra (digiteo id)");
            I1.verListaFuncio(conexao);
            idFuncionario = inN.nextInt();
            I1.setIdFuncionario(idFuncionario);
            
           System.out.println("Qual Produto deseja comprar? (digiteo id)");
           I1.verListaProd(conexao);
           idProduto = inN.nextInt();
           I1.setIdProduto(idProduto);
           
           System.out.println("A quantidade desse Produto?");
           quant = inN.nextInt();
           I1.setQuant(quant);
           
           I1.compra(conexao);
        }
        
        // ver lista de funcionario
        else if(i == 5){
            I1.verListaFuncio(conexao);
        }
        
        // cadastrar funcionario
        else if(i == 6){
            System.out.println("Digite o nome do FUNCIONARIO: ");
            nomeF = inL.nextLine();
            I1.setNomeF(nomeF);
            System.out.println("Digite o cargo do FUNCIONARIO: ");
            cargoF = inL.nextLine();
            I1.setCargoF(cargoF);
            I1.addFuncio(conexao); 
        }
        
        // demitir um funcionario
        else if(i == 7){
            I1.verListaFuncio(conexao);
            System.out.println("Digite o codigo do funcionario a ser DEMITIDO: ");
            idFuncionario = inN.nextInt();
            I1.setIdFuncionario(idFuncionario);
            I1.demitirFuncio(conexao);  
        }
        // ver lista de clientes
        else if(i == 8){
            I1.verListaClient(conexao);
        }
        
        // cadastrar novo cliente
        else if(i == 9){
            System.out.println("Digite o nome do CLIENTE a ser cadastrado");
            nomeC = inL.nextLine();
            I1.setNomeC(nomeC);
            I1.addClient(conexao);
        }
        
        // descadastrar cliente
        else if(i == 10){
            I1.verListaClient(conexao);
            System.out.println("Digite o codigo do cliente a ser DESCADASTRADO");
            idCliente = inN.nextInt();
            I1.setIdCliente(idCliente);
            I1.descadastrarClient(conexao);
        }
        
        }
    } 
}
