
import java.sql.Connection;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public interface Interface {
    
    public String getNomeP();
    public String getNomeF();
    public String getCargoF();
    public String getNomeC();
    public double getPrecoP();
    public double getPrecoPT();
    public int getQuant();
    public int getIdFuncionario();
    public int getIdProduto();
    public int getIdCliente();
    public void setNomeP(String nomeP);
    public void setNomeF(String nomeF);
    public void setCargoF(String cargoF);
    public void setNomeC(String nomeC);
    public void setPrecoP(double precoP);
    public void setPrecoPT(double precoPT);
    public void setQuant(int quant);
    public void setIdFuncionario(int idFuncionario);
    public void setIdCliente(int idCliente);    
    public void setIdProduto(int idProduto);
    
    
    
    public void salvarProd(Connection con);
    public void excluirProd(Connection con);
    public void verListaProd(Connection con);
    
    public void addFuncio(Connection con);
    public void verListaFuncio(Connection con);
    public void demitirFuncio(Connection con);
    
    public void addClient(Connection con);
    public void verListaClient(Connection con);
    public void descadastrarClient(Connection con);
    
    public void compra(Connection con);
    
}
