
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class Operacoes implements Interface{
    
    private String nomeP, nomeF, nomeC, cargoF;
    private double precoP, precoPT;
    private int idProduto, idCliente, idFuncionario, quant;
    
    public String getNomeP(){
        return this.nomeP;
    }
    
    public String getNomeF(){
        return this.nomeF;
    }
    
    public String getCargoF(){
        return this.cargoF;
    }
    
    public String getNomeC(){
        return this.nomeC;
    }
    
    public double getPrecoP(){
        return this.precoP;
    }
    
    public double getPrecoPT(){
        return this.precoPT;
    }
    
    public int getQuant(){
        return this.quant;
    }
    
    public int getIdFuncionario(){
        return this.idFuncionario;
    }
    
    public int getIdProduto(){
        return this.idProduto;
    }
    
    public int getIdCliente(){
        return this.idCliente;
    }
    
    public void setNomeP(String nomeP){
        this.nomeP = nomeP;
    }
    
    public void setNomeF(String nomeF){
        this.nomeF = nomeF;
    }
    
    public void setCargoF(String cargoF){
        this.cargoF = cargoF;
    }
    
    public void setNomeC(String nomeC){
        this.nomeC = nomeC;
    }
    
    public void setPrecoP(double precoP){
        this.precoP = precoP;
    }
    
    public void setPrecoPT(double precoPT){
        this.precoP = precoPT;
    }
    
    public void setQuant(int quant){
        this.quant = quant;
    }
    
    public void setIdFuncionario(int idFuncionario){
        this.idFuncionario = idFuncionario;
    }
    
    public void setIdCliente(int idCliente){
        this.idCliente = idCliente;
    }
    
    public void setIdProduto(int idProduto){
        this.idProduto = idProduto;
    }
    
    
    public void salvarProd(Connection con){
        
        try {
            String add = "INSERT INTO produtos(nome, preco) VALUES (? , ?)";
            PreparedStatement stm = con.prepareCall(add);
            stm.setString(1, this.getNomeP());
            stm.setInt(2, (int) this.getPrecoP());
            stm.executeUpdate();
   
            }
        catch (SQLException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
             }
        
    }
    
    public void verListaProd(Connection con){
        try {
            ResultSet rs = con.createStatement().executeQuery("select * from Produtos");
    
        while(rs.next()){
            System.out.println("Nome: " + rs.getString("nome") +
                        "// Preço: R$" + rs.getInt("preco") +
                    "// Codigo do Produto: " + rs.getInt("idproduto"));
        }
    }
        catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void excluirProd(Connection con){
        
        String sql = "DELETE FROM produtos WHERE idProduto = ?";
        try {
            
            PreparedStatement stm = con.prepareStatement(sql);
            stm.setInt(1, this.getIdProduto());
            stm.executeUpdate();
                  
    }
        catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
    public void addFuncio(Connection con){
        
        try {
            String add = "INSERT INTO funcionarios(nome, cargo) VALUES (? , ?)";
            PreparedStatement stm = con.prepareCall(add);
            stm.setString(1, this.getNomeF());
            stm.setString(2, this.getCargoF());
            stm.executeUpdate();
   
            }
        catch (SQLException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
             }
        
    }
    
    public void verListaFuncio(Connection con){
        try {
            ResultSet rs = con.createStatement().executeQuery("select * from Funcionarios");
    
        while(rs.next()){
            System.out.println("Nome: " + rs.getString("nome") +
                        "// Cargo: " + rs.getString("cargo") +
                    "// Codigo do Funcionario: " + rs.getInt("idfuncionario"));
        }
    }
        catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void demitirFuncio(Connection con){
        String sql = "DELETE FROM funcionarios WHERE idFuncionario = ?";
        try {
            
            PreparedStatement stm = con.prepareStatement(sql);
            stm.setInt(1, this.getIdFuncionario());
            stm.executeUpdate();
                  
    }
        catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void addClient(Connection con){
        try {
            String add = "INSERT INTO clientes(nome) VALUES (?)";
            PreparedStatement stm = con.prepareCall(add);
            stm.setString(1, this.getNomeC());
            stm.executeUpdate();
   
            }
        catch (SQLException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
             }
        
    }
    
    public void verListaClient(Connection con){
        try {
            ResultSet rs = con.createStatement().executeQuery("select * from Clientes");
    
        while(rs.next()){
            System.out.println("Nome: " + rs.getString("nome") +
                    "// Codigo do Cliente: " + rs.getInt("idcliente"));
        }
    }
        catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void descadastrarClient(Connection con){
        String sql = "DELETE FROM clientes WHERE idCliente = ?";
        try {
            
            PreparedStatement stm = con.prepareStatement(sql);
            stm.setInt(1, this.getIdCliente());
            stm.executeUpdate();
            
                  
    }
        catch (SQLException ex) {
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void compra(Connection con){
         try {
             
             ResultSet rs = con.createStatement().executeQuery
            ("select * from Produtos WHERE idProduto = " + this.getIdProduto());
            
            while(rs.next()){
                precoPT = (rs.getInt("preco") * this.getQuant());
                setPrecoPT(precoPT);
                System.out.println("preço total: " + this.getPrecoPT());
                }
             
            String add =
            "INSERT INTO vendas(idcliente, idproduto, idfuncionario, quantidade, precototal) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stm = con.prepareCall(add);
            stm.setInt(1, this.getIdCliente());
            stm.setInt(2, this.getIdProduto());
            stm.setInt(3, this.getIdFuncionario());
            stm.setInt(4, this.getQuant());
            stm.setInt(5, (int) this.getPrecoPT());
            stm.executeUpdate();
            
            
            
            }
        catch (SQLException ex) {
            Logger.getLogger(Operacoes.class.getName()).log(Level.SEVERE, null, ex);
             }
         
    }
    
}
        
